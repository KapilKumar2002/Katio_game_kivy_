.. _writer-api:

******
Writer
******

:mod:`ffpyplayer.writer`
=============================

.. automodule:: ffpyplayer.writer
   :members:
   :undoc-members:
   :show-inheritance:
