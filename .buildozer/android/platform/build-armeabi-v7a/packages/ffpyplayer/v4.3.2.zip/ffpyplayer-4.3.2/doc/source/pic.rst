.. _pic-api:

******
Images
******

:mod:`ffpyplayer.pic`
=============================

.. automodule:: ffpyplayer.pic
   :members:
   :undoc-members:
   :show-inheritance:
