.. _player-api:

******
Player
******

:mod:`ffpyplayer.player`
=============================

.. automodule:: ffpyplayer.player
   :members:
   :undoc-members:
   :show-inheritance:
